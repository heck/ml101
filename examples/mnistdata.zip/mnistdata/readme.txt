MNIST data in CSV format
Taken from
https://www.kaggle.com/oddrationale/mnist-in-csv/downloads/mnist-in-csv.zip/2
First column gives label, other columns give image pixels